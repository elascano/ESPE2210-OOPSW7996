class HelloWorld{
        public static void main(String[] args){
                System.out.println(" Hello Edison Lascano");
                System.out.println(" -------- My name is Sheylee Enriquez --------");
                System.out.println(" This is going to be a fantastic semester :)");
         }
}

