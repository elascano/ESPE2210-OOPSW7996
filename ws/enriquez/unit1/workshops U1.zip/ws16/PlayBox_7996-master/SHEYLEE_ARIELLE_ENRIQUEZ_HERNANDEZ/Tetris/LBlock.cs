﻿namespace Tetris
{
    public class LBlock 
    {

    }
}
