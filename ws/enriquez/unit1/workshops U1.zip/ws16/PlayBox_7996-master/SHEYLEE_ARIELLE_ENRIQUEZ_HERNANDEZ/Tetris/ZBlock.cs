﻿namespace Tetris
{
    public class ZBlock 
    {

    }
}
