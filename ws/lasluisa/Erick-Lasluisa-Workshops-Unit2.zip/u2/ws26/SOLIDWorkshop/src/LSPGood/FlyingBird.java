
package LSPGood;

/**
 *
 * @author Erick Lasluisa, Pythons, DCCO-ESPE
 */
public abstract class FlyingBird extends Bird{

    abstract void fly();

}
