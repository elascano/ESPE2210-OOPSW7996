package LSPGood;

/**
 *
 * @author Erick Lasluisa, Pythons, DCCO-ESPE
 */
public abstract class Bird {

    abstract void eat();
}
