package LSPGood;

/**
 *
 * @author Erick Lasluisa, Pythons, DCCO-ESPE
 */
public class Ostrich extends Bird {

    @Override
    void eat() {
        System.out.println("Ostrich is Eating");
    }

}
