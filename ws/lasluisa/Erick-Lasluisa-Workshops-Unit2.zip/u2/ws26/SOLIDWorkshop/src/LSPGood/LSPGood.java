package LSPGood;

/**
 *
 * @author Erick Lasluisa, Pythons, DCCO-ESPE
 */
public class LSPGood {

    public static void main(String[] args) {
        // TODO code application logic here
        Bird ostrich = new Ostrich();
        Duck duck = new Duck();
        ostrich.eat();
        duck.eat();
        duck.fly();
    }
}
