package OCPGood;

/**
 *
 * @author Erick Lasluisa, Pythons, DCCO-ESPE
 */
public abstract class DrivingMode {

    public abstract int getPower();

    public abstract int getSuspensionHeigh();

}
