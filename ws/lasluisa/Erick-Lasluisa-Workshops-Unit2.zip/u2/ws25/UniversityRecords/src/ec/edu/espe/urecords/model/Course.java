
package ec.edu.espe.urecords.model;

/**
 *
 * @author Erick Lasluisa, Pythons, DCCO-ESPE
 */
public class Course {
    
}
