package ec.edu.espe.figure.model;

/**
 *
 * @author Erick Lasluisa, Pythons, DCCO-ESPE
 */
public abstract class Shape {

    public abstract float calculateArea();

    public abstract float calculatePerimeter();
}
