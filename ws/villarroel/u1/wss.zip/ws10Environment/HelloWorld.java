class HelloWorld{
	public static void main(String[] args){
		System.out.println(" Hello Object Oriented Programming Students");
		System.out.println(" --------- My name is Justin Villarroel ---------");
		System.out.println("We will learn new language programming :) ");
	}
}