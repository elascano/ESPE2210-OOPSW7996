﻿namespace Tetris
{
    public class SBlock 
    {

    }
}
