﻿namespace Tetris
{
    public class IBlock
    {

    }
}
