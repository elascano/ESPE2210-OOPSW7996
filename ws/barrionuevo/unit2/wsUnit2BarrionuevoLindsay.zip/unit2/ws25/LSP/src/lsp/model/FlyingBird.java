package lsp.model;

/**
 *
 * @author Lindsay Barrionuevo,DeltaTeam, DCCO-ESPE
 */
public abstract class FlyingBird extends Bird{

    void fly() {
        System.out.println("Flying");
    }

}
