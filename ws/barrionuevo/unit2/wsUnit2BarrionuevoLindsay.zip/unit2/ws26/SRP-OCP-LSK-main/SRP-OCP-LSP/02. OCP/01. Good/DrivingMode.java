package ocp;

/**
 *
 * @author Lindsay Barrionuevo , DeltaTeam, DCCO-ESPE
 */

public interface DrivingMode {

    public abstract int getPower();

    public abstract int getSuspensionHeight();

}