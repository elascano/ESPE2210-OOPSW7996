package lsp;

/**
 *
 * @author Lindsay Barrionuevo,DeltaTeam, DCCO-ESPE
 */

public abstract class Bird {

    void eat() {
        System.out.println("Eating");
    }
}