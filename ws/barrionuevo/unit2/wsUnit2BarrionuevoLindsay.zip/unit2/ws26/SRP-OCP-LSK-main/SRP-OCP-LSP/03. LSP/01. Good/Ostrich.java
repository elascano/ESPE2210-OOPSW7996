package lsp;

/**
 *
 * @author Lindsay Barrionuevo,DeltaTeam, DCCO-ESPE
 */

public class Ostrich extends Bird {

    void eat() {
        System.out.println("Eating");
    }
}