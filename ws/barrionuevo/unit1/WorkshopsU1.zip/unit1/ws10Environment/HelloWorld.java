class HelloWorld {
	public static void main(String[] args) {
		System.out.println(" Hello Edison and OOP classmates");
		System.out.println(" ---My name is Lindsay Barrionuevo---");
		System.out.println(" Love what you do");
	}
}

