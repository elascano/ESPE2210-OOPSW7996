﻿namespace Tetris
{
    public class OBlock 
    {

    }
}
