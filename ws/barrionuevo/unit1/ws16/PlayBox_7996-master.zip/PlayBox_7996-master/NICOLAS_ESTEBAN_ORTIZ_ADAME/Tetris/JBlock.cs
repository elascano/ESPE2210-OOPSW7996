﻿namespace Tetris
{
    public class JBlock
    {

    }
}
