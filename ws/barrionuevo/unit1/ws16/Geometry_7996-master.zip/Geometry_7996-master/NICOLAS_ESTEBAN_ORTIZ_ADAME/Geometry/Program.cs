﻿using System;

namespace Geometry
{
    class Program
    {
        static void Main(string[] args)
        {
            //Rectangle , Square, Circle
            //Area, Perimeter
            //Abstraction
            //Encupsulation
            //Inheritance
            //Polymorphisn

        }
    }
}
