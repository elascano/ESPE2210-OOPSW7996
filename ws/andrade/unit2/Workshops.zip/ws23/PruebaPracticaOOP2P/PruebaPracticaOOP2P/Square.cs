﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PruebaPracticaOOP2P
{
    internal class Square : Rectangle
    {
        public Square(double width) : base(width, width)
        {

        }
    }
}
