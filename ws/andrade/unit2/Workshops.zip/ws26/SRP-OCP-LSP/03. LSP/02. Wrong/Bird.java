package lsp;

/**
 *
 * @author nicko
 */
public abstract class Bird {
    abstract void fly();
    abstract void eat();
}
