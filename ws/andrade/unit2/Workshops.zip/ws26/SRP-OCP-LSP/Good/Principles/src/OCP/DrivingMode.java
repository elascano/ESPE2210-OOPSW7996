
package OCP;

/**
 *
 * @author Alejandro Andrade, Scriptal, DCCO_ESPE
 */
public interface DrivingMode {
    
    public abstract int getPower();
    public abstract int getSuspensionHeigh();
    
}
