
package LSP;

/**
 *
 * @author Alejandro Andrade, Scriptal, DCCO_ESPE
 */
public abstract class Bird {
    
    public abstract void eat();
    
}
