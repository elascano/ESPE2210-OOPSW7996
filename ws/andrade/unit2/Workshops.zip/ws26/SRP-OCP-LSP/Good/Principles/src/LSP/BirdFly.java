
package LSP;

/**
 *
 * @author Alejandro Andrade, Scriptal, DCCO_ESPE
 */
public abstract class BirdFly extends Bird{
    
    public abstract void fly();
    
}
