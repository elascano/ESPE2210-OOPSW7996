
package LSP;

/**
 *
 * @author Alejandro Andrade, Scriptal, DCCO_ESPE
 */
public class Ostrich extends Bird{

    @Override
    public void eat() {
        System.out.println("Ostrich eat");
    }
    
}
