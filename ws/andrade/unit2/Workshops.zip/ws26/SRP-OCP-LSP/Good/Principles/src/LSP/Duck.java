
package LSP;

/**
 *
 * @author Alejandro Andrade, Scriptal, DCCO_ESPE
 */
public class Duck extends BirdFly{

    @Override
    public void fly() {
        System.out.println("Duck fly");
    }

    @Override
    public void eat() {
        System.out.println("Duck eat");
    }
    
    
    
}
