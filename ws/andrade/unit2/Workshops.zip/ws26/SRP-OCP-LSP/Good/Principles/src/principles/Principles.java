
package principles;

/**
 *
 * @author Alejandro Andrade, Scriptal, DCCO_ESPE
 */
public class Principles {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
    }
    
}
