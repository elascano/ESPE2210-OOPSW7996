class HelloWord {
	public static void main(String[] args) {
		System.out.println("Hello OOP classmates");
		System.out.println("---------My name is Alejandro Andrade--------");
		System.out.println("There is no one who knows enough to say what is and what is not possible.");
	}
}