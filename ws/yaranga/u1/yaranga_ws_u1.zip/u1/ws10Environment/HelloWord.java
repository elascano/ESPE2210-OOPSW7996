class HelloWorld{
	public static void main (String[] args) {
		System.out.println("Hello Object Oriented Programming Students ");
		System.out.println(" --------My name is Leonardo Yaranga-------");
		System.out.println("This is going to be an awesome semester :D");
	}
}