
package taller.principios.srp.ocp.lcp.GoodLSP;

/**
 *
 * @author Leonardo Yaranga,Progress Team, DCCO-ESPE
 */
public abstract class FlyingBird extends Bird{

    void fly() {
        System.out.println("Flying");
    }

}
