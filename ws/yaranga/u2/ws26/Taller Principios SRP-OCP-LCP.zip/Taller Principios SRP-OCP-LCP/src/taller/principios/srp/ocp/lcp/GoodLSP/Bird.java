
package taller.principios.srp.ocp.lcp.GoodLSP;

/**
 *
 * @author Leonardo Yaranga,Progress Team, DCCO-ESPE
 */
public abstract class Bird {

    void eat() {
        System.out.println("Eating");
    }
}
