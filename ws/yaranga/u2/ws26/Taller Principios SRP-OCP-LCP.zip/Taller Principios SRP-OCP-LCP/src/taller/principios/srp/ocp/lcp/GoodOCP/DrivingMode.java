
package taller.principios.srp.ocp.lcp.GoodOCP;

/**
 *
 * @author Leonardo Yaranga,Progress Team, DCCO-ESPE
 */
public abstract class DrivingMode {

    public abstract int getPower();

    public abstract int getSuspensionHeigh();

}
