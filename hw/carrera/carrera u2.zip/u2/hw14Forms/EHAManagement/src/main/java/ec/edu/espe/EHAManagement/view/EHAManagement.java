package ec.edu.espe.ehamanagement.view;

/**
 *
 * @author Nahir Carrera, Gaman GeekLords, DCC0-ESPE
 */
public class EHAManagement {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
