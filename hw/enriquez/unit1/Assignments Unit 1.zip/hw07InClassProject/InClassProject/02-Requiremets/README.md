# Requirements
SRS (IEEE-830) and other needed documents to gather customers' needs
