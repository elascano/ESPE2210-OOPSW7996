
package ec.edu.espe.chickenfarm.model;

/**
 *
 * @author Sheylee Enriquez, Developer Bears, DCCO-ESPE
 */
public class ChickenFarmer {
    
}
