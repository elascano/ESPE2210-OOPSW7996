
package ec.edu.espe.hw09.exeptions;

/**
 *
 * @author Alejandro Andrade, Scriptal, DCCO_ESPE
 */
public class CustomEx extends Exception{
    
    public static final long serialVersonUID = 700L;
    
    public CustomEx(String message){
        super(message);
    }
    
}
