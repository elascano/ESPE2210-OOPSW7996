
package ec.edu.espe.controller;

/**
 *
 * @author Alejandro Andrade, Scriptal, DCCO_ESPE
 */
public class CtrCellPhone {
    
}
