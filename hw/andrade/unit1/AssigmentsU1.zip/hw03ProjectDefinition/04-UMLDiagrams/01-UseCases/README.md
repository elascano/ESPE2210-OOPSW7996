# SCRIPTAL
### - Scripttastic! -
### UseCases
### We are:
- Cristian Jose Acalo Cruz (CrisAcalo)
- Karla Alejandra Ansatuña Andrade (KarlaAns)
- Luis Alejandro Andrade Encalada (MrBowis)
- Bernardo Andre Aldaz Vidal (baaldaz)