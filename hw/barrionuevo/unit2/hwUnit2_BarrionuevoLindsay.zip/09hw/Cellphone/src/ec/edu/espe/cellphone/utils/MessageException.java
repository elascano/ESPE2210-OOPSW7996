
package ec.edu.espe.cellphone.utils;

/**
 *
 * @author Barrionuevo Lindsay, DeltaTeam, DCCO-ESPE
 */
public class MessageException extends Exception{

    public static final long serialVersionUID = 700L;

    public MessageException(String message) {
        super(message);
    }
}
