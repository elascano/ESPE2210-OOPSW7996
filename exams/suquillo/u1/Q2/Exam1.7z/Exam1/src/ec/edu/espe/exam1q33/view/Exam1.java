
package ec.edu.espe.exam1q33.view;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import ec.edu.espe.exam1q33.model.Fork;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.*;
import java.util.Scanner;

/**
 *
 * @author Martín Suquillo, WebMasterTeam, DCCO_ESPE
 */
public class Exam1 {

    public static void main(String[] args) {
        
        Scanner sc = new Scanner(System.in);
        boolean exitMenu = false;
        int option = 0;
        ArrayList<Fork> forks = new ArrayList<>();
        
        while (!exitMenu)
        {

            try
            {
                System.out.println("CHOOSE AN OPTION");
                System.out.println("1. Enter new fork");
                System.out.println("2. Exit");
                System.out.println("Choose any option: ");
                option = sc.nextInt();

                switch (option)
                {
                    case 1:
                        forks = readJson(forks);
                        enterNewFork(forks);
                        addToJson(forks);
                        System.out.println("Fork successfully added");
                        break;
                    case 2:
                        exitMenu = true;
                        break;
                    default:
                        System.out.println("invalid value");
                }
            } catch (InputMismatchException e)
            {
                System.out.println("Incorrect value");
            }
        }
        
    }

    private static void addToJson(ArrayList<Fork> forks) {
        File fileJson = new File("ForksList.json");
        Gson gson = new Gson();
        String json = gson.toJson(forks);

        try
        {
            FileWriter writer = new FileWriter(fileJson);
            writer.write(json);
            writer.close();
        } catch (FileNotFoundException e)
        {
            e.printStackTrace(System.out);
        } catch (IOException e)
        {
            e.printStackTrace(System.out);
        }
    }

    private static ArrayList<Fork> readJson(ArrayList<Fork> forks) {
      
        Gson gson = new Gson();

        try
        {
            BufferedReader br = new BufferedReader(new FileReader("MouseList.json"));
            String line = "";
            line = br.readLine();
            TypeToken<ArrayList<Fork>> type = new TypeToken<ArrayList<Fork>>() {};
            forks = gson.fromJson(line, type.getType());
            br.close();
        } catch (FileNotFoundException ex)
        {
            System.out.println("Sorry, file not found");
        } catch (IOException ex)
        {
            System.out.println("The file is empy");
        }
        return forks;
    }

    private static void enterNewFork(ArrayList<Fork> mouses) {
        Fork mouse = new Fork();
        Scanner sc = new Scanner(System.in);

        System.out.println("Enter the fork id");
        mouse.setId(sc.nextInt());
        System.out.println("Enter the fork material");
        mouse.setName(sc.next());
        System.out.println("Enter true or false if is usable");
        mouse.setRgb(sc.nextBoolean());

        mouses.add(mouse);
    }
    
}
