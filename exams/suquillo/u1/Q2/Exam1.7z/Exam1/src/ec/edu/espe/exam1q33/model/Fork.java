
package ec.edu.espe.exam1q33.model;

/**
 *
 * @author Martín Suquillo, WebMasterTeam, DCCO_ESPE
 */
public class Fork {
    private int id;
    private String name;
    private boolean material;
    
    public Fork() {
        id = 0;
        name = "";
        material = false;
    }

    @Override
    public String toString() {
        return "mouse{" + "id=" + id + ", name=" + name + ", Good material=" + material + '}';
    }
    
    

    /**
     * @return the id
     */
    public int getId() {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(int id) {
        this.id = id;
    }

    /**
     * @return the name
     */
    public String getName() {
        return name;
    }

    /**
     * @param name the name to set
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * @return the rgb
     */
    public boolean isRgb() {
        return material;
    }

    /**
     * @param rgb the rgb to set
     */
    public void setRgb(boolean rgb) {
        this.material = rgb;
    }
    
        
    
}
