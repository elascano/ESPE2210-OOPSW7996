package ec.edu.espe.fromumltocode.model;

/**
 *
 * @author Erick Lasluisa, Pythons, DCCO-ESPE
 */
public abstract class A {
    A objectA;
}
