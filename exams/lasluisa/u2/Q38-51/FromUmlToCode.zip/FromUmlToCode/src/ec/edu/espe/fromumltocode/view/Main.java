package ec.edu.espe.fromumltocode.view;

/**
 *
 * @author Erick Lasluisa, Pythons, DCCO-ESPE
 */
public class Main {
    public static void main(String[] args) {
        
        
        
    }
}
