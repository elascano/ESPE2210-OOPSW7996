package ec.edu.espe.exercise61.controller;
import ec.edu.espe.exercise61.model.stadium;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.mongodb.MongoException;
import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoClients;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoCursor;
import com.mongodb.client.MongoDatabase;
import com.mongodb.client.model.Filters;
import com.mongodb.client.model.Updates;
import ec.edu.espe.fashionstore.model.Measurement;
import ec.edu.espe.fashionstore.model.Order;
import static java.util.Locale.filter;
import java.util.Scanner;
import org.bson.Document;
import org.bson.conversions.Bson;
import org.bson.types.ObjectId;
/**
 *
 * @author Miguel Gutierrez, Pythons, DCCO-ESPE
 */
public class StadiumController {
    
 private static final Scanner sc = new Scanner(System.in);
    //private static final Order order = new Order();
    private static final Stadium stadium = new Stadium();

    public static void insertDocumentMongo(MongoDatabase database, Order order) {

        MongoCollection<Document> collection = database.getCollection("Orders");
        Document inspection = new Document("_id", new ObjectId())
                .append("id", order.getId())
                .append("name", order.getname())
                .append("size", order.getsize());


        collection.insertOne(inspection);

    }

    public static Order readMongo(MongoDatabase database, int id) {
        Order order;
        String document = "";
        Gson gson = new Gson();

        MongoCollection<Document> collection = database.getCollection("Stadiums");

        Bson filter = Filters.eq("id", id);
        Document query = collection.find(Filters.and(filter)).first();

        document = query.toJson();
        TypeToken<Order> type = new TypeToken<Order>() {
        };
        order = gson.fromJson(document, type.getType());

        return order;

    }

    public static boolean noRepeatOrder(MongoDatabase database, Order order, boolean existOrder) {

        MongoCollection<Document> collection2 = database.getCollection("Stadiums");
        Bson filter = Filters.and(Filters.all("id", order.getId()));

        if (collection2.find(filter).first() == null) {
            existOrder = false;
        }
        if (collection2.find(filter).first() != null) {
            existOrder = true;
        }
        return existOrder;

    }

    public static void updateMongo(MongoDatabase database, Order order) {
        MongoCollection<Document> collection = database.getCollection("Stadiums");
        Bson query = Filters.eq("id", order.getId());
        Bson filter = Filters.and(Filters.all("id", order.getId()));

        if (collection.find(filter).first() != null) {

            Bson updates;
            updates = Updates.combine(Updates.set("Stadiums", order.getCustomerName()),
                    Updates.set("id", order.getPhoneNumber()),
                    Updates.set("name", order.getMeasurement().getNeckMeasurement()),
                    Updates.set("size", order.getMeasurement().getChestMeasurement()),

            collection.updateOne(query, updates);

        } else {
            System.out.println("Stadium not found");
        }
    }

    public static void deleteMongo(MongoDatabase database, Order order) {

        MongoCollection<Document> collection = database.getCollection("Stadiums");
        Bson query = Filters.eq("id", order.getId());
        Bson filter = Filters.and(Filters.all("id", order.getId()));

        if (collection.find(filter).first() != null) {

            collection.deleteOne(query);

        } else {
            System.out.println("Stadium not found");
        }

    }   
}


