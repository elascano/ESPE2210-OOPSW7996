/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ec.edu.espe.exam3.controller;

/**
 *
 * @author Miguel Gutierrez, Pythons, DCCO-ESPE
 */
public class BubbleSort implements SortingStrategy{
    
    public int[] sort(int data[]){
        int dataLen, auxiliar, sortedData[];
        dataLen = data.length;
        
        sortedData = new int[dataLen];
        System.arraycopy(data, 0, sortedData, 0, dataLen);
        
        for (int i = 0; i <dataLen-1; i++) {
            for (int j = 0; j < dataLen-1; j++) {
                if (sortedData[j] > sortedData[j+1]){
                    auxiliar = sortedData[j];
                    sortedData[j] = sortedData[j+1];
                    sortedData[j+1] = auxiliar;
                }
            }
        }
        
        return sortedData;
    }
}