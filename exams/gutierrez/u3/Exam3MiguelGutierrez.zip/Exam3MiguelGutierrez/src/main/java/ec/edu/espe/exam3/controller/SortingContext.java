/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ec.edu.espe.exam3.controller;
/**
 *
 * @author Miguel Gutierrez, Pythons, DCCO-ESPE
 */
public class SortingContext implements SortingStrategy{
    private SortingStrategy sortingStrategy;
    
    public int[] sort(int data[]){
        int size = data.length;
        sortingStrategy = setSortingStrategy(size);
        return sortingStrategy.sort(data);
    }
    
    private SortingStrategy setSortingStrategy(int size){
        if(size > 0 && size < 3){
            sortingStrategy = new BubbleSort();
        } else if(size < 7){
            sortingStrategy = new InsertionSort();
        } else{
            sortingStrategy = new QuickSort();
        }
        
        return sortingStrategy;
    }
}


