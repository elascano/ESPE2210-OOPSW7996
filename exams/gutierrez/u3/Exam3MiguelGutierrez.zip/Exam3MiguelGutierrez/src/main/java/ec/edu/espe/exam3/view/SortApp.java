/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */

package ec.edu.espe.exam3.view;
import ec.edu.espe.exam3.controller.SortingContext;
import java.util.Arrays;
/**
 *
 * @author Miguel Gutierrez, Pythons, DCCO-ESPE
 */
public class SortApp {

    public static void main(String[] args) {
        int data[ ] = {3,6,4,6,7,8,5,6,7,5,3,3};
        SortingContext sc = new SortingContext();
        int sortedList[ ] = sc.sort(data);
        System.out.println(Arrays.toString(sortedList));
        System.out.println(Arrays.toString(data));
    }
}