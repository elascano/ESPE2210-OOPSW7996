/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ec.edu.espe.exam3.controller;

/**
 *
 * @author Miguel Gutierrez, Pythons, DCCO-ESPE
 */
public class InsertionSort implements SortingStrategy{
    
public int[] sort(int data[]){
        int sortedData[], dataLen;
        dataLen = data.length;
        
        sortedData = new int[dataLen];
        System.arraycopy(data, 0, sortedData, 0, dataLen);
        
        for (int i = 1; i < dataLen; ++i) {
            int key = sortedData[i];
            int j = i - 1;
 
            while (j >= 0 && sortedData[j] > key) {
                sortedData[j + 1] = sortedData[j];
                j = j - 1;
            }
            sortedData[j + 1] = key;
        }
        return sortedData;
    }
}
