/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ec.edu.espe.exam3.controller;

/**
 *
 * @author Miguel Gutierrez, Pythons, DCCO-ESPE
 */
public class QuickSort implements SortingStrategy{
    
public int[] sort(int data[]){
        int sortedData[], dataLength;
        dataLength = data.length;
        
        sortedData = new int[dataLength];
        System.arraycopy(data, 0, sortedData, 0, dataLength);
        
        quickSort(sortedData, 0, dataLength - 1);
        return sortedData;
    }
    
    private static void quickSort(int[] arr, int left, int right) {
        if (left < right) {
            int pivotIndex = partition(arr, left, right);
            quickSort(arr, left, pivotIndex - 1);
            quickSort(arr, pivotIndex + 1, right);
        }
    }
    
    private static int partition(int[] arr, int left, int right) {
        int pivotIndex = choosePivotIndex(left, right);
        int pivotValue = arr[pivotIndex];
        swap(arr, pivotIndex, right);
        int storeIndex = left;
        for (int i = left; i < right; i++) {
            if (arr[i] < pivotValue) {
                swap(arr, i, storeIndex);
                storeIndex++;
            }
        }
        swap(arr, storeIndex, right);
        return storeIndex;
    }
    
    private static int choosePivotIndex(int left, int right) {
        return (left + right) / 2;
    }
    
    private static void swap(int[] arr, int i, int j) {
        int temp = arr[i];
        arr[i] = arr[j];
        arr[j] = temp;
    }
}

