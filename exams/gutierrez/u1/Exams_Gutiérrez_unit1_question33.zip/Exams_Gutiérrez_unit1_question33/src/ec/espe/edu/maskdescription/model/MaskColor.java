/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ec.espe.edu.maskdescription.model;

/**
 *
 * @author Miguel Gutierrez, Pythons, DCCO-ESPE
 */
public class MaskColor {
    private String maskcolor;
    private String author;
    private String publisher;
    private String yearPublication;

    public Class1(String title, String author, String publisher, String yearPublication) {
        this.title = title;
        this.author = author;
        this.publisher = publisher;
        this.yearPublication = yearPublication;
    }

    @Override
    public String toString() {
        return "Book{" + "title=" + title + ", author=" + author + ", publisher=" + publisher + ", yearPublication=" + yearPublication + '}';
    }

}
