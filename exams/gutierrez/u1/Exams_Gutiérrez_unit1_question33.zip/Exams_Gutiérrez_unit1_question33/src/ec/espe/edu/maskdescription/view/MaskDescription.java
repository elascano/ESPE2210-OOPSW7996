/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ec.espe.edu.maskdescription.view;

import java.util.ArrayList;
import com.google.gson.Gson;
import com.google.gson.JsonSyntaxException;
import com.google.gson.reflect.TypeToken;
import ec.espe.edu.maskdescription.model.maskcolor
import ec.espe.edu.maskdescription.model.maskdesign
import ec.espe.edu.maskdescription.model.maskid
/**
 *
 * @author Miguel Gutierrez, Pythons, DCCO-ESPE
 */
public class MaskDescription {

    File= newfile
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args)       {
        ArrayList<Class1> mask;
        int MaskDesign;
        mask = new ArrayList<>(); 
        
        
        for(int i=0; i<4;i++){
            mask.add(i, new Class1("maskcolor", "maskid", "maskdesign"));
        }
        for(MaskDesign printf: mask){
            System.out.println(printf);
        }
    Gson gson = new Gson();
        String json = gson.toJson(maskdesign);
        File file = new File("clothmodel.json");
        try ( FileWriter fw = new FileWriter(file);) {            
            fw.write(json);   
    }
 
}
