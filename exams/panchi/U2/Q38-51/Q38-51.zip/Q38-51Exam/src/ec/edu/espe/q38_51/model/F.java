package ec.edu.espe.q38_51.model;

/**
 *
 * @author Allan Panchi, GiftSoft Team, DCCO-ESPE
 */
public class F {
    
}
