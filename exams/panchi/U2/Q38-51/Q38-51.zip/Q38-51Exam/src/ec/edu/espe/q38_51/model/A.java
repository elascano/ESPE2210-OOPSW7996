package ec.edu.espe.q38_51.model;

import java.util.ArrayList;

/**
 *
 * @author Allan Panchi, GiftSoft Team, DCCO-ESPE
 */
public class A {
    ArrayList<A> a = new ArrayList<>();
}
