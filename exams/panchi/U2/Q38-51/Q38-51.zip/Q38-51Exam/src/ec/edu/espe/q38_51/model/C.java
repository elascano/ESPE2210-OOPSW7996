package ec.edu.espe.q38_51.model;

import java.util.ArrayList;

/**
 *
 * @author Allan Panchi, GiftSoft Team, DCCO-ESPE
 */
public abstract class C{
    ArrayList<E> e = new ArrayList<E>();
}
