package ec.edu.espe.q38_51.view;

/**
 *
 * @author Allan Panchi, GiftSoft Team, DCCO-ESPE
 */
public class FromUMLtoCodeQ38_51 {
    public static void main(String[] args) {
        
    }
}
