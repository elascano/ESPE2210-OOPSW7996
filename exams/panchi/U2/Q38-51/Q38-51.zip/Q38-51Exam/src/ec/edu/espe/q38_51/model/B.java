package ec.edu.espe.q38_51.model;

import java.util.ArrayList;

/**
 *
 * @author Allan Panchi, GiftSoft Team, DCCO-ESPE
 */
public class B extends H{
    ArrayList<B> b = new ArrayList<>();
}
