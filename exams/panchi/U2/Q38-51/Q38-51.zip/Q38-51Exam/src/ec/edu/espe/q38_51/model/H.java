package ec.edu.espe.q38_51.model;

import java.util.ArrayList;

/**
 *
 * @author Allan Panchi, GiftSoft Team, DCCO-ESPE
 */
public abstract class H {
    ArrayList<H> h = new ArrayList<>();
}
