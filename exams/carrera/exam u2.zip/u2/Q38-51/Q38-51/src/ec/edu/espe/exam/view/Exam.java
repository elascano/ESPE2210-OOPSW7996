/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ec.edu.espe.exam.view;

import ec.edu.espe.exam.model.B;
import ec.edu.espe.exam.model.C;
import ec.edu.espe.exam.model.D;
import ec.edu.espe.exam.model.E;

/**
 *
 * @author kevin
 */
public class Exam {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        B b = new B();
        C c = new C();
        D d = new D();
        E e = new E();
        c.print(e);
    }
    
}
