
package exam2q38;

/**
 *
 * @author Alejandro Andrade, Scriptal, DCCO_ESPE
 */
public class Main {
    
    public static void main(String[] args){
        A a;
    }
    
}
