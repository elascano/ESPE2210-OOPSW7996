
package exam2q38;

/**
 *
 * @author Alejandro Andrade, Scriptal, DCCO_ESPE
 */
public class E {

    public E() {
    }
    
    @Override
    public String toString() {
        return "F{" + '}';
    }
    
}
