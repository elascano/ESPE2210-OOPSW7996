
package exam2q38;

/**
 *
 * @author Alejandro Andrade, Scriptal, DCCO_ESPE
 */
public class F {

    public F() {
    }

    @Override
    public String toString() {
        return "F{" + '}';
    }
    
    
}
