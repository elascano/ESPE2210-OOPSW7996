
package exam2q38;

/**
 *
 * @author Alejandro Andrade, Scriptal, DCCO_ESPE
 */
public interface H {
    
}
