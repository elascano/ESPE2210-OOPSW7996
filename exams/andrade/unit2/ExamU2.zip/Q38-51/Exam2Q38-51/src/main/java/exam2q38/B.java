
package exam2q38;

import java.util.ArrayList;

/**
 *
 * @author Alejandro Andrade, Scriptal, DCCO_ESPE
 */
public class B extends A{
    
    public B(ArrayList<A> as) {
        super(as);
    }
    
}
