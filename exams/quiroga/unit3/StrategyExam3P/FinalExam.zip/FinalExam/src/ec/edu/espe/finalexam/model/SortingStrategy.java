/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ec.edu.espe.finalexam.model;

import ec.edu.espe.finalexam.model.ListNumbers;

/**
 *
 * @author Francisco Quiroga, Search Engine Bandits , DCCO-ESPE
 */
    public abstract class SortingStrategy {
    public abstract void sort(ListNumbers listOfNumbers);
}
