package ec.espe.edu.q6170.model;

/**
 *
 * @author Joel Rivera
 */
public class Plate {
    
    private String name;
    private long id;
    private String plateCode;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getPlateCode() {
        return plateCode;
    }

    public void setPlateCode(String plateCode) {
        this.plateCode = plateCode;
    }
    
    
    
}
