
package ec.edu.espe.codediagram.model;

/**
 *
 * @author Lindsay Barrionuevo, DeltaTeam, DCCO-ESPE
 */
public class C {
    
}
