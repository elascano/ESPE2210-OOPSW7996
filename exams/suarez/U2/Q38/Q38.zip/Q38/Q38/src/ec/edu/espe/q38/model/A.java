
package ec.edu.espe.q38.model;

/**
 *
 * @author Matias Suarez,WebMasterTeam,DCCO-ESPE
 */
public class A {
    
}
