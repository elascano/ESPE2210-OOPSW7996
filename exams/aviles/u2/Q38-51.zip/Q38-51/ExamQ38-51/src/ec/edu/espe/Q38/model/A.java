package ec.edu.espe.Q38.model;

/**
 *
 * @author Daniel Aviles, DeltaTeam, DCCO-ESPE
 */
public abstract class A {
    private A a;
}
