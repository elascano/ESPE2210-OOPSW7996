package ec.edu.espe.Q38.view;

import ec.edu.espe.Q38.model.A;
import ec.edu.espe.Q38.model.B;
import ec.edu.espe.Q38.model.C;
import ec.edu.espe.Q38.model.D;
import ec.edu.espe.Q38.model.H;
import ec.edu.espe.Q38.model.E;
import ec.edu.espe.Q38.model.F;
import ec.edu.espe.Q38.model.G;
import ec.edu.espe.Q38.model.J;
import java.util.ArrayList;

/**
 *
 * @author Daniel Aviles, DeltaTeam, DCCO-ESPE
 */
public class ExamQ3851 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        A a;
        J j;
        G g;
        A a1;
        A a2;
        ArrayList<E> e = null;
        
        ArrayList<F> f = null;
        a1 = new C(e);
        a2 = new D(e,f);
        ArrayList<H> h = null;
        a = new B(h);
        
        j = new J();
        
        g = new G();
        
        
        g.method(j);
        
    }
    
}
