package ec.edu.espe.Q38.model;

import java.util.ArrayList;

/**
 *
 * @author Daniel Aviles, DeltaTeam, DCCO-ESPE
 */
public class C extends A{
    private ArrayList<E> e;

    public C(ArrayList<E> e) {
        this.e = e;
    }

    public ArrayList<E> getE() {
        return e;
    }

    public void setE(ArrayList<E> e) {
        this.e = e;
    }
}
