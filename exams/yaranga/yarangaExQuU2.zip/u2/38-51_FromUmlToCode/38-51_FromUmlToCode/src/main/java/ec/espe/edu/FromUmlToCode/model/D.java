/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ec.espe.edu.FromUmlToCode.model;

import java.util.ArrayList;

/**
 *
 * @author H303
 */
public class D {
   
    private E[] ed;
    private ArrayList<F> fd;

    /**
     * @return the ed
     */
    public E[] getEd() {
        return ed;
    }

    /**
     * @param ed the ed to set
     */
    public void setEd(E[] ed) {
        this.ed = ed;
    }

    

    
  
   

   

   

    
    
    
}
