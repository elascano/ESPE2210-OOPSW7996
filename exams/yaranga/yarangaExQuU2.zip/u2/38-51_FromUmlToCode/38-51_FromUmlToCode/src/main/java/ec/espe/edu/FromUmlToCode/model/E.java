/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ec.espe.edu.FromUmlToCode.model;

/**
 *
 * @author H303
 */
public class E {
    private int e;

    public E(int e) {
        this.e = e;
    }

    public E() {
        this.e = 0;
    }

    /**
     * @return the e
     */
    public int getE() {
        return e;
    }

    /**
     * @param e the e to set
     */
    public void setE(int e) {
        this.e = e;
    }
    
}
