package ec.edu.espe.exam.model;

/**
 *
 * @author Sheylee Enriquez, Developer Bears, DCCO-ESPE
 */
public interface SortingStrategy {
    public int[ ] sort( int data[ ] );
} 

